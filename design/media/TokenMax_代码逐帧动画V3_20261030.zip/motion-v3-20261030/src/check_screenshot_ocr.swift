import Foundation
import Vision
import ImageIO

let url = URL(fileURLWithPath: CommandLine.arguments[1])
let req = VNRecognizeTextRequest()
req.recognitionLevel = .accurate
req.recognitionLanguages = ["zh-Hans", "en-US"]
req.usesLanguageCorrection = false
let handler = VNImageRequestHandler(url: url, options: [:])
do { try handler.perform([req]) }
catch { fputs("OCR unavailable: \(error)\n", stderr); exit(2) }
for item in req.results ?? [] {
    if let text = item.topCandidates(1).first { print(text.string) }
}
